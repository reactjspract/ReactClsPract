import React from 'react'

const ShowData = () => {
  return (
    <div>
      <input type="text" className="text" placeholder="Enter name" />
      <input type="text" className="text" placeholder="Enter name" />
      <input type="text" className="text" placeholder="Enter name" />
    </div>
  );
}

export default ShowData