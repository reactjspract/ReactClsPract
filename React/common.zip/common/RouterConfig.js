import React, { lazy, Suspense } from "react";
import { Routes, Route } from "react-router-dom";
import PageNotFound from "./PageNotFound";
import GuessNumber6, {
  GuessNumber1,
  GuessNumber2,
  GuessNumber3,
  GuessNumber4,
  GuessNumber5,
} from "../guess-number/GuessNumber";
import ErrorBoundary from "./ErrorBoundary";

const Layout = lazy(() => import("../Layout/Layout"));
const TodoApp = lazy(() => import("../todo-app/TodoApp"));
const UserDetailForm = lazy(() => import("../users-details/UserDetailForm"));
const UserDetails = lazy(() => import("../users-details/UserDetails"));
const CounterApp = lazy(() => import("./CounterApp"));
const TableData = lazy(() => import("../table-data/TableData"));
const MemeApp = lazy(() => import("../meme-app/MemeApp"));

const RouterConfig = () => {
  return (
    <Suspense fallback={<h2>Loading........</h2>}>
      <Routes>
        <Route path="/" element={<Layout />} />
        <Route path="/home" element={<Layout />} />
        <Route
          path="/counter"
          element={
            <ErrorBoundary>
              <CounterApp />
            </ErrorBoundary>
          }
        />
        <Route path="/user-details" element={<UserDetails />} />
        <Route path="/user-details-form" element={<UserDetailForm />} />
        <Route path="/todo-app" element={<TodoApp />} />
        <Route
          path="/table-data"
          element={
            <ErrorBoundary>
              <TableData />
            </ErrorBoundary>
          }
        />
        <Route path="/meme-app" element={<MemeApp />} />
        <Route
          path="/guess-no"
          element={
            <GuessNumber6>
              <h2>Props.children</h2>
              <GuessNumber1 />
              <GuessNumber2 />
              <GuessNumber3 />
              <GuessNumber4 />
              <GuessNumber5 />
            </GuessNumber6>
          }
        />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </Suspense>
  );
};

export default RouterConfig;
