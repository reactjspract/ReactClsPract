import React from "react";

const UserActions = (props) => {
  const { handleChange, handleClick, handleSelect, userDetail } = props;
  const { name, age, city } = userDetail;

  return (
    <>
      <div>
        <label htmlFor="username">Set Name here: </label>
        <input
          placeholder="User name here..."
          value={name}
          onChange={handleChange}
          id="username"
        />
      </div>
      <div>
        <label htmlFor="city">Set City here: </label>
        <select id="city" onChange={handleSelect} defaultValue={city}>
          <option value="">Select the city</option>
          <option value="Hyderabad">Hyderabad</option>
          <option value="Banglore">Banglore</option>
          <option value="Chennai">Chennai</option>
          <option value="Mumbai">Mumbai</option>
          <option value="Delhi">Delhi</option>
        </select>
      </div>
      <div className="btn-group">
        {/* <button onClick={handleInc}>Age ++ </button>
        <button onClick={handleDec}>Age -- </button> */}
        <button onClick={() => handleClick(age + 1)}>Age ++ </button>
        <button onClick={() => handleClick(age - 1)}>Age -- </button>
      </div>
    </>
  );
};

export default UserActions;
