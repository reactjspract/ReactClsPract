import React, { Component } from "react";

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isError: false,
    };
  }

  componentDidCatch(error) {
    if (error) {
      this.setState({
        isError: true,
      });
    }
  }

  render() {
    if (this.state.isError) {
      return (
        <div className="error-boundary">
          <h2>Something went wrong, Please try again later.</h2>
          <p>
            Please report the issue.{" "}
            <a href="mailto:veerendra.nagella@gmail.com">Mail us</a>{" "}
          </p>
        </div>
      );
    } else {
      return this.props.children;
    }
  }
}

export default ErrorBoundary;
