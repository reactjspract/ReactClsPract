import React, { useState } from "react";

const CounterApp = () => {
  const [counter, setcounter] = useState(0);
  const [counterVal, setcounterVal] = useState(1);
  const [countObj, setcountObj] = useState({
    incClickCount: 0,
    decClickCount: 0,
  });
  const [counterErrorMessage, setcounterErrorMessage] = useState("");

  const handleClick = (val, inc, dec) => {
    setcountObj({
      incClickCount: inc,
      decClickCount: dec,
    });
    if (inc > 10 || dec > 10) {
      setcounterErrorMessage("You clicked 10 times either inc or dec");
    } else if (val < 0) {
      setcounter(0);
      setcounterErrorMessage("No negative values allowed");
    } else if (val === 0) {
      setcounter(val);
      setcounterErrorMessage("Values resetted");
    } else if (val > 50) {
      setcounterErrorMessage(
        `Maximun inc is 50 only reached and Inc value is ${counterVal}`
      );
    } else {
      setcounter(val);
      setcounterErrorMessage("");
    }
  };

  const handleChange = (e) => {
    if (e.target.value) {
      const val = parseInt(e.target.value);
      setcounterVal(val);
    }
  };

  return (
    <div className="counter-app">
      <div style={{ margin: "10px 0" }}>
        <select value={counterVal} onChange={handleChange}>
          {new Array(100).fill(10).map((item, index) => {
            return (
              <option value={index + 1} key={index}>
                {index + 1}
              </option>
            );
          })}
        </select>
      </div>
      <h2>Counter Value: {counter} </h2>
      <div className="btn-group">
        <button
          onClick={() =>
            handleClick(counter + counterVal, countObj.incClickCount + 1, 0)
          }
        >
          Counter INC
        </button>
        <button
          onClick={() =>
            handleClick(counter - counterVal, 0, countObj.decClickCount + 1)
          }
        >
          Counter DEC
        </button>
        <button onClick={() => handleClick(0, 0, 0)}>Counter RES</button>
      </div>
      <br />
      {counterErrorMessage && <p>{counterErrorMessage}</p>}
    </div>
  );
};

export default CounterApp;
