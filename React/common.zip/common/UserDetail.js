import React, { useMemo } from "react";

const UserDetail = (props) => {
  const { userDetail } = props;
  const { name, city, age, userName } = userDetail;

  const userDetailValues = useMemo(() => {
    console.log("use memo");
    return { name, city, age, userName };
  }, [name, city, age, userName]);
  // const { name, city, age, userName } = userDetailValues;

  console.log("calling", userDetailValues);

  return (
    <>
      <div>
        <strong>User Name:</strong> <em>{userDetailValues.name}</em>
      </div>
      <div>
        <strong>City:</strong> <em>{userDetailValues.city}</em>
      </div>
      <div>
        <strong>Age:</strong> <em>{userDetailValues.age}</em>
      </div>
      <div>
        <strong>UserName:</strong> <em>{userDetailValues.userName}</em>
      </div>
    </>
  );
};

export default UserDetail;
