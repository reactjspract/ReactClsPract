import React from "react";
import data from "./usersData.json";

const Layout = () => {
  return (
    <div className="layout-columns">
      {data.usersData.map((user) => {
        return (
          <div key={user.name}>
            <h3>{user.name}</h3>
            <span>{user.age}</span>
            <em>{user.city}</em>
          </div>
        );
      })}
    </div>
  );
};

export default Layout;
