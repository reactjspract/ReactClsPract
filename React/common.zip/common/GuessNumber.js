import React from "react";

// const GuessNumber = () => {
//   return <h2>Guess Number</h2>;
// };

// export default GuessNumber;

// export default function GuessNumber() {
//   return <h2>Guess Number</h2>;
// }

export const GuessNumber1 = () => {
  return <h2>Guess Number1</h2>;
};
export const GuessNumber2 = () => {
  return <h2>Guess Number2</h2>;
};
export const GuessNumber3 = () => {
  return <h2>Guess Number3</h2>;
};
export const GuessNumber4 = () => {
  return <h2>Guess Number4</h2>;
};
export const GuessNumber5 = () => {
  return <h2>Guess Number5</h2>;
};
export default function GuessNumber6(props) {
  return (
    <div>
      {props.children}
      <h2>Guess Number6</h2>
    </div>
  );
}
