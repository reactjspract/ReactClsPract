import React, { useState } from "react";
import MemeBanner from "../../assets/images/meme-banner.jfif";

const MemeApp = () => {
  // const [topText, settopText] = useState("");
  // const [bottomText, setbottomText] = useState("");

  const [loadImage, setloadImage] = useState("");
  const [meme, setmeme] = useState({
    topText: "Top Text",
    bottomText: "Bottom Text",
    imageBanner: MemeBanner,
    isCover: true,
    pickColor: "#FFF",
    textColor: "#FFF",
    height: "200",
    left: "50",
    right: "50",
    top: "30",
    bottom: "30",
    rotate: "0",
  });

  const {
    topText,
    bottomText,
    imageBanner,
    isCover,
    pickColor,
    textColor,
    height,
    top,
    bottom,
    left,
    right,
    rotate,
  } = meme;

  const handleChange = (e) => {
    setmeme({
      ...meme,
      [e.target.name]: e.target.value,
    });
  };

  const handleImageChange = (e) => {
    const reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);

    reader.onload = () => {
      console.log(reader.result);
      setloadImage(reader.result);

      //base64encoded string
    };
    reader.onerror = (error) => {
      console.log("Error: ", error);
    };
  };

  const handleSubmit = () => {
    setmeme({
      ...meme,
      imageBanner: loadImage,
    });
  };

  return (
    <div className="meme-app">
      <h2>Meme App</h2>
      {/* <div className="input-1">
        <label htmlFor="input1">
          <input
            type="text"
            placeholder="Enter top text"
            id="input1"
            value={topText}
            onChange={(e) => settopText(e.target.value)}
          />
        </label>
      </div>
      <br />
      <div className="input-2">
        <label htmlFor="input1">
          <input
            type="text"
            placeholder="Enter top text"
            id="input1"
            value={bottomText}
            onChange={(e) => setbottomText(e.target.value)}
          />
        </label>
      </div> */}
      <div className="color-pick">
        <label htmlFor="input5">Pick the backgroud color:</label>
        &nbsp; &nbsp;
        <input
          type="color"
          id="input5"
          value={pickColor}
          name="pickColor"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="text-color-pick">
        <label htmlFor="input6">Pick the text color:</label>
        &nbsp; &nbsp;
        <input
          type="color"
          id="input6"
          value={textColor}
          name="textColor"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="input-1">
        <label htmlFor="input1">Top Text:</label>
        &nbsp; &nbsp;
        <input
          type="text"
          placeholder="Enter top text"
          id="input1"
          value={topText}
          name="topText"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="input-2">
        <label htmlFor="input2">Bottom Text:</label>
        &nbsp; &nbsp;
        <input
          type="text"
          placeholder="Enter top text"
          id="input2"
          value={bottomText}
          name="bottomText"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="height">
        <label htmlFor="height">Height: </label>
        &nbsp; &nbsp;
        <input
          type="number"
          placeholder="height"
          id="height"
          value={height}
          name="height"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="rotate">
        <label htmlFor="rotate">Rotate: </label>
        &nbsp; &nbsp;
        <input
          type="number"
          placeholder="rotate"
          id="rotate"
          value={rotate}
          name="rotate"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="top">
        <label htmlFor="top">Top:</label>
        &nbsp; &nbsp;
        <input
          type="number"
          placeholder="top"
          id="top"
          value={top}
          name="top"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="left">
        <label htmlFor="left">Left:</label>
        &nbsp; &nbsp;
        <input
          type="number"
          placeholder="left"
          id="left"
          value={left}
          name="left"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="right">
        <label htmlFor="right">Right:</label>
        &nbsp; &nbsp;
        <input
          type="number"
          placeholder="right"
          id="right"
          value={right}
          name="right"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="bottom">
        <label htmlFor="bottom">Bottom:</label>
        &nbsp; &nbsp;
        <input
          type="number"
          placeholder="bottom"
          id="bottom"
          value={bottom}
          name="bottom"
          onChange={handleChange}
        />
      </div>
      <br />
      <div className="image-loader">
        <label htmlFor="input3">Backgroud Image: </label>
        &nbsp; &nbsp;
        <input type="file" onChange={handleImageChange} name="imageBanner" />
        &nbsp; &nbsp;
        <button onClick={handleSubmit}>Submit</button>
      </div>
      <br />
      <div
        className="check-item"
        style={{ display: "flex", alignItems: "baseline" }}
      >
        <label htmlFor="input4">Is cover:</label>
        &nbsp;
        <input
          type="checkbox"
          id="input4"
          style={{ width: "18px", height: "18px" }}
          checked={isCover}
          onChange={(e) =>
            setmeme({
              ...meme,
              isCover: e.target.checked,
            })
          }
        />
      </div>
      <br />
      <MemeContainer
        bottomText={bottomText}
        topText={topText}
        imageBanner={imageBanner}
        isCover={isCover}
        pickColor={pickColor}
        textColor={textColor}
        height={height}
        top={top}
        bottom={bottom}
        left={left}
        right={right}
        rotate={rotate}
      />
    </div>
  );
};

const MemeContainer = (props) => {
  const {
    topText,
    bottomText,
    imageBanner,
    isCover,
    pickColor,
    textColor,
    height,
    top,
    bottom,
    left,
    rotate,
  } = props;

  return (
    <div
      className="meme-container"
      style={{ backgroundColor: pickColor, color: textColor }}
    >
      <p
        className="top-text"
        style={{ top: `${top}px`, left: `${left}%`, rotate: `${rotate}deg` }}
      >
        {topText}
      </p>
      <p
        className="bottom-text"
        style={{
          bottom: `${bottom}px`,
          left: `${left}%`,
          rotate: `${rotate}deg`,
        }}
      >
        {bottomText}
      </p>
      <img
        src={imageBanner}
        alt="Meme Banner"
        style={{
          objectFit: isCover ? "cover" : "contain",
          height: `${height}px`,
        }}
      />
    </div>
  );
};

export default MemeApp;
