import React, { useState } from "react";
import todoData from "./todo.json";

const OldTodoApp = () => {
  const [newTodo, setnewTodo] = useState("");
  const [todoItems, settodoItems] = useState(todoData);

  const completedStyle = {
    fontStyle: "italic",
    textDecoration: "line-through",
    color: "gray",
  };

  const intialStyles = {
    fontStyle: "normal",
    textDecoration: "none",
    color: "black",
  };

  const handleChange = (e) => {
    setnewTodo(e.target.value);
  };

  const handleSubmit = () => {
    if (newTodo && !todoItems.some((todo) => todo.title === newTodo)) {
      const newItem = {
        id: Math.floor(Math.random() * 100000 + 1),
        title: newTodo,
        completed: false,
      };
      settodoItems([...todoItems, newItem]);
      setnewTodo("");
    }
  };

  const handleUpdate = (todoItem) => {
    const updatedItems = todoItems.map((todo) => {
      if (todo.id === todoItem.id) {
        todo.completed = !todo.completed;
      }

      return todo;
    });

    settodoItems(updatedItems);
  };

  const handleDelete = (todoItem) => {
    const deletedItems = todoItems.filter((todo) => todo.id !== todoItem.id);
    settodoItems(deletedItems);
  };

  return (
    <div className="todo-container">
      <h2>Todo List: </h2>
      <div className="add-todo-section">
        <label htmlFor="add-todo"> Add todo here: </label>
        <input
          type="text"
          placeholder="Add todo here..."
          id="add-todo"
          value={newTodo}
          onChange={handleChange}
        />
        &nbsp;
        <button onClick={handleSubmit}>Add Todo</button>
      </div>
      <br />
      <ul style={{ paddingLeft: "30px", background: "lightgray" }}>
        {todoItems.length ? (
          todoItems.map((todo) => {
            return (
              <li key={todo.id}>
                <input
                  type="checkbox"
                  checked={todo.completed}
                  onChange={() => handleUpdate(todo)}
                />
                &nbsp;
                <span style={todo.completed ? completedStyle : intialStyles}>
                  {todo.title}
                </span>
                &nbsp;
                <button onClick={() => handleDelete(todo)}>Delete</button>
              </li>
            );
          })
        ) : (
          <div>No todo items</div>
        )}
      </ul>
    </div>
  );
};

export default OldTodoApp;
