import React from "react";

const TestPage = (props) => {
  // let { userAge } = props;
  // let userAge = props.userAge;

  const [userName, setuserName] = React.useState("Test User");

  const handleClick = () => {
    setuserName("Test User Updated");
  };

  return (
    <>
      <h2>
        {userName} -- {props.userAge} asn
      </h2>
      <button onClick={handleClick}>Change Name</button>
    </>
  );
};

export default TestPage;
