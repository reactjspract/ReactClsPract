import React, { useState } from "react";
// import Question from "./Question";
// import { quizData } from "../data/quizData";
import quizData from "./quizQues.json";

const Quiz = () => {
  const [savedData, setSavedData] = useState([]);
  const [index, setIndex] = useState(0);
  const [correctScore, setCorrectScore] = useState(0);
  const [incorrectScore, setIncorrectScore] = useState(0);

  const handleSubmit = () => {
    const finalScore = calculateQuizScore(savedData, quizData);
    setCorrectScore(finalScore);
    setIncorrectScore(quizData.length - finalScore);
  };

  const handleAnswer = (answer) => {
    setSavedData([...savedData, answer]);
    setIndex(index + 1);
  };

  const calculateQuizScore = (savedData, quizData) => {
    let score = 0;
    quizData.forEach((question, index) => {
      if (index < savedData.length && question.correct === savedData[index]) {
        score = score + 1;
      }
    });
    return score;
  };

  return (
    <div>
      {index < quizData.length ? (
        <Question
          question={quizData[index]}
          index={index}
          handleAnswer={handleAnswer}
        />
      ) : (
        <div>
          <h1>Quiz Completed!</h1>
          <p>Correct answers: {correctScore}</p>
          <p>Incorrect answers: {incorrectScore}</p>
          <button onClick={handleSubmit}>Submit</button>
        </div>
      )}
    </div>
  );
};

export default Quiz;
