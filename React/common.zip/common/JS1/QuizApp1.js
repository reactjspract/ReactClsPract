import React, { useState, Fragment } from "react";
import quizArray from "./quizQues.json";

const QuizApp = () => {
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);
  const [index, setIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [correctScore, setCorrectScore] = useState(true);
  const [incorrectScore, setIncorrectScore] = useState(false);
  const [savedData, setSavedData] = useState([]);

  const handleCountChange = (e) => {
    setCount(parseInt(e.target.value));
  };

  const handleStartQuiz = () => {
    setStarted(true);
  };

  // const handleAnswerSubmit = (e) => {
  //   e.preventDefault();
  //   const currentQuestion = quizArray[index];

  //   if (answer === currentQuestion.answer) {
  //     setCorrectScore(correctScore + 1);
  //   } else {
  //     setIncorrectScore(incorrectScore + 1);
  //   }

  //   if (index === count - 1) {
  //     setSavedData([...savedData, answer]);
  //   }

  //   if (index < count - 1) {
  //     setIndex(index + 1);
  //     setAnswer("");
  //     setSavedData([...savedData, answer]);
  //   }
  // };

  const handleAnswerSubmit = (e) => {
    e.preventDefault();
    const currentQuestion = quizArray[index];

    if (answer === currentQuestion.answer) {
      setCorrectScore(correctScore + 1);
    } else {
      setIncorrectScore(incorrectScore + 1);
    }

    if (index + 1 === count) {
      calculateScore();
    } else {
      setIndex(index + 1);
      setAnswer("");
      setSavedData([...savedData, answer]);
    }
  };

  // const calculateScore = () => {
  //   const finalScore = calculateQuizScore(savedData, quizArray);
  //   setCorrectScore(finalScore);
  //   setIncorrectScore(count - finalScore);
  // };

  // const calculateScore = () => {
  //   const finalScore = calculateQuizScore(savedData, quizArray);
  //   setCorrectScore(finalScore);
  //   setIncorrectScore(count - finalScore);
  //   setIndex(count);
  // };

  const calculateScore = () => {
    const finalScore = calculateQuizScore(savedData, quizArray);
    setCorrectScore(finalScore);
    setIncorrectScore(count - finalScore);
    setIndex(0);
  };

  const calculateQuizScore = (savedData, quizData) => {
    let score = 0;
    quizData.forEach((question, index) => {
      if (question.answer === savedData[index]) {
        score += 1;
      }
    });
    return score;
  };

  return (
    <div>
      <h3>Welcome to Javascript Quiz</h3>
      {!started ? (
        <div>
          <p>Select no of questions</p>
          <select value={count} onChange={handleCountChange}>
            <option value="0">Select</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
          </select>
          <br />
          <button onClick={handleStartQuiz} disabled={!count}>
            Start Quiz
          </button>
        </div>
      ) : (
        <div>
          <h4>You selected {count} questions </h4>
          {index < count ? (
            <form onSubmit={handleAnswerSubmit}>
              <h2>{quizArray[index].question}</h2>
              {quizArray[index].options.map((option) => (
                <div key={option}>
                  <input
                    type="radio"
                    name="answer"
                    value={option}
                    checked={answer === option}
                    onChange={(e) => setAnswer(e.target.value)}
                  />
                  <label>{option}</label>
                </div>
              ))}
              <br />
              <button type="submit">Next question</button>
            </form>
          ) : (
            <div>
              <p>Quiz completed!</p>
              <p>Correct answers: {correctScore}</p>
              <p>Incorrect answers: {incorrectScore}</p>
              <button onClick={calculateScore}>Calculate score</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default QuizApp;

// const handleAnswerSubmit = (e) => {
//   e.preventDefault();
//   const currentQuestion = quizArray[index];

//   if (answer === currentQuestion.answer) {
//     setCorrectScore(correctScore + 1);
//   } else {
//     setIncorrectScore(incorrectScore + 1);
//   }

//   if (index + 1 === count) {
//     calculateScore();
//   } else {
//     setIndex(index + 1);
//     setAnswer("");
//     setSavedData([...savedData, answer]);
//   }
// };

// // const calculateScore = () => {
// //   const finalScore = calculateQuizScore(savedData, quizArray);
// //   setCorrectScore(finalScore);
// //   setIncorrectScore(count - finalScore);
// // };

// const calculateScore = () => {
//   const finalScore = calculateQuizScore(savedData, quizArray);
//   setCorrectScore(finalScore);
//   setIncorrectScore(count - finalScore);
//   setIndex(count);
// };

// const calculateScore = () => {
//   const finalScore = calculateQuizScore(savedData, quizArray);
//   setCorrectScore(finalScore);
//   setIncorrectScore(count - finalScore);
//   setIndex(0);
// };
