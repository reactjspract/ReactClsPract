// Reverse a String:

const reverseString = (name) => {
  let reverseStr = name.toLowerCase().split("").reverse().join("");
  console.log(`Reverse a string of ${name} is ${reverseStr}`);
};
reverseString("Kalyani");

// Check Palindrome:
const checkPalindrome = (input) => {
  let reverseInput = input.toLowerCase().split("").reverse().join("");
  if (reverseInput === input.toLowerCase()) {
    console.log(`Yes, ${input} is a palindrome`);
  } else {
    console.log(`No, "${input}" is a not palindrome`);
  }
};
checkPalindrome("Madam");
checkPalindrome("12321");

// Count Vowels:

const countVowels = (str) => {
  let c = 0;
  for (let i = 0; i < str.length; i++) {
    if (["a", "e", "i", "o", "u"].includes(str.toLowerCase().charAt(i))) {
      c++;
    }
  }
  console.log(`Count vowels of "${str}" is ${c++}`);
};
countVowels("kalyani US");

// Capitalize First Letter of multiple words:

const capitalizeFirstLetter = (str) => {
  let strSplit = str.split(" ");
  let getFirstLetterCapt = strSplit.map((word) => {
    const strFirstLetter = word.charAt(0).toUpperCase();
    const remainLetters = word.slice(1);
    return strFirstLetter + remainLetters;
  });
  const arrayJoin = getFirstLetterCapt.join(" ");
  // console.log(typeof arrayJoin); // string
  console.log(arrayJoin);
};
capitalizeFirstLetter("hello rayavarapu hari");

// Remove Duplicates:
const removeDuplicates = (str) => {
  let output = "";
  for (let i = 0; i < str.length; i++) {
    let letter = str.toLowerCase().charAt(i);
    if (output.indexOf(letter) === -1) {
      output += letter;
    }
  }
  console.log(`Removed duplicates from "${str}" is "${output}"`);
};
removeDuplicates("kAlyani");
