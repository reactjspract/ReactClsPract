import React, { useState, useEffect } from "react";
import axios from "axios";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import { toast } from "react-toastify";
import Modal from "react-bootstrap/Modal";

export default function TableData() {
  const [userData, setuserData] = useState([]);
  const [userDataOriginal, setuserDataOriginal] = useState([]);
  const [searchStr, setsearchStr] = useState("");
  const [label, setlabel] = useState("Submit");
  const [deletedItem, setdeletedItem] = useState({});
  const [updateUser, setupdateUser] = useState({});
  const [modalShow, setModalShow] = useState(false);
  const [formData, setformData] = useState({
    name: "",
    email: "",
    city: "",
    number: "",
  });
  const { name, email, number, city } = formData;

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const axiosResponse = await axios.get("http://localhost:5000/users");
      const filData = axiosResponse.data.map((user) => {
        const newUser = {
          id: user._id,
          name: user.name,
          email: user.email,
          city: user.address,
          number: user.contact,
        };
        return newUser;
      });
      setuserData(filData);
      setuserDataOriginal(filData);
    } catch (error) {
      console.log("Error", error);
    }
  };

  const iteratorFunc = (obj, searchKey) => {
    for (const key in obj) {
      if (typeof obj[key] === "object") {
        return iteratorFunc(obj[key], searchKey);
      } else {
        if (obj[key].toString().toLowerCase().includes(searchKey)) {
          return true;
        }
      }
    }
    return false;
  };

  const handleChange = (e) => {
    setsearchStr(e.target.value);

    const itemsFilter = userDataOriginal.filter((user) =>
      iteratorFunc(user, e.target.value)
    );

    setuserData(itemsFilter);
  };

  const handleFormChange = (e) => {
    setformData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleAddUser = (e) => {
    e.preventDefault();
    if (name && email && city && number) {
      if (
        userData.every(
          (user) =>
            user.email.toLowerCase().trim() !== email.toLowerCase().trim()
        )
      ) {
        axios({
          method: "POST",
          url: "http://localhost:5000/users",
          data: {
            name: name,
            email: email,
            address: city,
            contact: number,
          },
          headers: {
            "Content-Type": "application/json",
          },
        })
          .then((res) => {
            toast.success(
              res.data?.message || "User added Successfully in the API"
            );
            fetchData();
            setformData({
              name: "",
              email: "",
              city: "",
              number: "",
            });
          })
          .catch((err) => {
            toast.error("Something went wrong while adding the User");
            console.log(err);
          });
      } else {
        toast.info("Given email already exists");
      }
    } else {
      toast.info("Please fill all the fields");
    }
  };

  const handleDelete = async () => {
    try {
      const response = await axios.delete(
        `http://localhost:5000//user/${deletedItem.id}`
      );
      toast.success(response.data?.message || "User deleted");
      fetchData();
      setModalShow(false);
    } catch (error) {
      toast.success("User deletion failed");
      setModalShow(false);
    }
  };

  const handleEdit = (user) => {
    setupdateUser(user);
    setformData({
      ...user,
    });

    setlabel("Update");
  };

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.put(
        `http://localhost:5000//user/${updateUser.id}`,
        {
          name: name,
          email: email,
          contact: number,
          address: city,
        }
      );
      toast.success(response.data?.message || "User updated");
      fetchData();
      setformData({
        name: "",
        email: "",
        city: "",
        number: "",
      });
      setlabel("Submit");
    } catch (error) {
      toast.success("User updation failed");
      setModalShow(false);
    }
  };

  return (
    <div className="crud-data">
      <h2>CRUD Operations</h2>
      <br />
      <Container>
        <Row>
          <Col xm={4}>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  name="email"
                  value={email}
                  onChange={handleFormChange}
                />
                <Form.Text className="text-muted">
                  We'll never share your email with anyone else.
                </Form.Text>
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicName">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Name"
                  name="name"
                  value={name}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicCity">
                <Form.Label>City</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="City"
                  name="city"
                  value={city}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicContact Number">
                <Form.Label>Contact Number</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Contact Number"
                  name="number"
                  value={number}
                  onChange={handleFormChange}
                />
              </Form.Group>
              <Button
                variant="primary"
                type="submit"
                onClick={label === "Submit" ? handleAddUser : handleUpdateUser}
              >
                {label}
              </Button>
            </Form>
          </Col>
          <Col>
            <div className="table-data" style={{ marginTop: "10px" }}>
              <input
                placeholder="Search"
                value={searchStr}
                onChange={handleChange}
              />
              <br />
              <br />
              <table>
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>City</th>
                    <th>Contact</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {userData && userData.length ? (
                    userData.map((user, index) => {
                      return (
                        <tr key={user.id}>
                          <td>{index + 1}</td>
                          <td>{user.name}</td>
                          <td>{user.email}</td>
                          <td>{user.city}</td>
                          <td>{user.number}</td>
                          <td>
                            <div className="btn-group">
                              <Button
                                variant="secondary"
                                onClick={() => handleEdit(user)}
                              >
                                Edit
                              </Button>
                              <Button
                                variant="danger"
                                onClick={() => {
                                  setdeletedItem(user);
                                  setModalShow(true);
                                }}
                              >
                                Delete
                              </Button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    <tr>
                      <td>No data</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Col>
        </Row>
      </Container>
      <Modal
        show={modalShow}
        onHide={() => setModalShow(false)}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">Delete</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div>
            Are you sure want to delete the user: <em>{deletedItem.name}</em>
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={() => setModalShow(false)}>Close</Button>
          <Button variant="danger" onClick={handleDelete}>
            Delete
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
