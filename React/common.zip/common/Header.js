import "../../assets/css/header.css";
import menuData from "./menuData.json";
import HeroImage from "../../assets/images/hero-icon.png";
import { NavLink } from "react-router-dom";

function Header() {
  return (
    <header>
      <div className="hero-section">
        <h3>
          <NavLink to="/" title="Freshify Pvt. Ltd">
            <img src={HeroImage} alt="freshify-icon" />
            <span>{"Freshify"}</span>
          </NavLink>
        </h3>
      </div>
      <div className="menu-bar">
        <nav className="nav-links">
          <ul>
            {menuData.map((item) => {
              return (
                <li key={item.name}>
                  <NavLink
                    className={({ isActive, isPending }) =>
                      isActive ? "active" : isPending ? "pending" : ""
                    }
                    to={item.link}
                  >
                    {item.name}
                  </NavLink>
                </li>
              );
            })}
          </ul>
        </nav>
      </div>
    </header>
  );
}

export default Header;
