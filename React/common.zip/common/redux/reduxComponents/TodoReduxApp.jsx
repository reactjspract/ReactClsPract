import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { connect } from "react-redux";
import { getTodos, addTodo } from "../actions/todosAction";

const TodoReduxApp = () => {
  const dispatch = useDispatch();
  const [newTodo, setNewTodo] = useState("");
  const { todos } = useSelector((state) => state.todos);

  useEffect(() => {
    dispatch(getTodos());
  }, [dispatch]);

  const handleAddTodo = async () => {
    if (
      newTodo &&
      !todos.some(
        (todo) =>
          todo.title.toLowerCase().trim() === newTodo.toLowerCase().trim()
      )
    ) {
      try {
        const todoItem = {
          title: newTodo,
          completed: false,
        };
        await dispatch(addTodo(todoItem));
        setNewTodo("");
        dispatch(getTodos());
      } catch (err) {
        console.log(err);
      }
    } else {
      alert(
        newTodo ? "Todo is already in the list" : "Todo name must be provided"
      );
    }
  };

  return (
    <section>
      <h3>Todo Application With Redux</h3>
      <input
        type="text"
        placeholder="Add todo here"
        value={newTodo}
        onChange={(e) => setNewTodo(e.target.value)}
      />
      <button onClick={handleAddTodo}>Add</button>
      {todos.map((todo) => {
        return (
          <>
            <input type="checkbox" name="todo" id="todo" />
            <label htmlFor="todo">{todo.title}</label>
          </>
        );
      })}
    </section>
  );
};

export default TodoReduxApp;
