// import { Profiler } from "react";
import { useDispatch, useSelector } from "react-redux";
import { counterInc, counterDec, counterReset } from "../actions/counter";

const CounterWithRedux = () => {
  const dispatch = useDispatch();
  const { count } = useSelector((state) => state.counter);

  /*const data = useSelector((state) => state);
  console.log("data isssss", data); 
  o/p: {counter: {…}, todos: {…}}
*/

  /*const data = useSelector((state) => state.counter);
  console.log("data isssss", data); 
  o/p: {count: 0}
*/
  //  id, // the "id" prop of the Profiler tree that has just committed
  //    phase, // either "mount" (if the tree just mounted) or "update" (if it re-rendered)
  //    actualDuration, // time spent rendering the committed update
  //    baseDuration, // estimated time to render the entire subtree without memoization
  //    startTime, // when React began rendering this update
  //    commitTime, // when React committed this update
  //    interactions // the Set of interactions belonging to this update
  // const counterLog = (
  //   id,
  //   phase,
  //   actualDuration,
  //   baseDuration,
  //   startTime,
  //   commitTime,
  //   interactions
  // ) => {
  //   console.log(
  //     id,
  //     phase,
  //     actualDuration / 1000,
  //     baseDuration / 1000,
  //     startTime / 1000,
  //     commitTime / 1000,
  //     interactions
  //   );
  // };

  return (
    <div>
      {/* <Profiler id="counter-sec" onRender={counterLog}> */}
      <h4>Counter With Redux example</h4>
      <p>Count value is {count}</p>
      <button onClick={() => dispatch(counterInc())}>INC</button>
      <button onClick={() => dispatch(counterDec())}>DEC</button>
      <button onClick={() => dispatch(counterReset())}>RESET</button>
      {/* </Profiler> */}
    </div>
  );
};

export default CounterWithRedux;
