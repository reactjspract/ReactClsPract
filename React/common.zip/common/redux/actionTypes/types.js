export const INC = "INC";
export const DEC = "DEC";
export const RESET = "RESET";

export const TODO_START = 'TODO_START';
export const TODO_SUCESS = 'TODO_SUCESS';
export const TODO_FAIL = 'TODO_FAIL';