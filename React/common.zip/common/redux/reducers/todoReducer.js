import { TODO_FAIL, TODO_START, TODO_SUCESS } from "../actionTypes/types";

const inititalData = {
  todos: [],
  loading: false,
  error: ''
}

export const todoReducer = (state = inititalData, action) => {
  switch (action.type) {
    case TODO_START:
     return {...state, loading: true}
    case TODO_SUCESS:
     return {...state, loading: false,todos: action.data}
    case TODO_FAIL:
     return {...state,loading: false, error: 'Something is went wrong, please recheck'}
    default:
      return state;
  }
}