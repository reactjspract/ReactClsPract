import { combineReducers } from "@reduxjs/toolkit";
import { countReducer} from "./countReducer";
import { todoReducer } from "./todoReducer";



 const rootReducer = combineReducers({
  counter: countReducer, todos: todoReducer
 })

export default rootReducer;