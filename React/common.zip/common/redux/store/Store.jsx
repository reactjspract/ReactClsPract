import thunk from "redux-thunk";
import rootReducer from "../reducers/rootReducer";
const { configureStore } = require("@reduxjs/toolkit");

export const store = configureStore({
  reducer: rootReducer,
  middleware: [thunk],
});
