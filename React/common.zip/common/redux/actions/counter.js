import { DEC, INC, RESET } from "../actionTypes/types";

export const counterInc = () => (dispatch) => {
  dispatch({type: INC})
}
export const counterDec = () => (dispatch) => {
  dispatch({type: DEC})
}
export const counterReset = () => (dispatch) => {
  dispatch({type: RESET})
}

