import axios from "axios";
import todoItems from "../actionTypes/todoItems.json";
import { TODO_FAIL, TODO_START, TODO_SUCESS } from "../actionTypes/types";

export const getTodos = () => (dispatch) => {
  dispatch({
    type: TODO_START,
  });

  axios(todoItems)
    .then((res) => {
      const todosdata = res.data.map((todo) => ({ ...todo, id: todo._id }));
      dispatch({ type: TODO_SUCESS, data: todosdata });
    })
    .catch((err) => {
      dispatch({
        type: TODO_FAIL,
        err: err?.message || "Something went wrong",
      });
    });
};

export const addTodo= (data) => () => {
  return todoItems.push(data);
};
