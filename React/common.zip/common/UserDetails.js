import React, { useState} from "react";
import UserActions from "./UserActions";
import UserDetail from "./UserDetail";
// import UserDetailForm from "./UserDetailForm";

const UserDetails = () => {
  const [userDetail, setuserDetail] = useState({
    name: "",
    city: "",
    age: null,
    userName: "test",
  });
  // const handleInc = () => {
  //   setuserDetail({
  //     ...userDetail,
  //     age: userDetail.age + 1,
  //   });
  // };

  // const handleDec = () => {
  //   setuserDetail({
  //     ...userDetail,
  //     age: userDetail.age - 1,
  //   });
  // };

  const handleClick = (age) => {
    setuserDetail({
      ...userDetail,
      age, // age: age,
    });
  };

  const handleChange = (e) => {
    setuserDetail({
      ...userDetail,
      name: e.target.value,
    });
  };

  const handleSelect = (e) => {
    setuserDetail({
      ...userDetail,
      city: e.target.value,
    });
  };

  return (
    <div className="user-details">
      <UserActions
        userDetail={userDetail}
        handleChange={handleChange}
        handleClick={handleClick}
        handleSelect={handleSelect}
      />
      <UserDetail userDetail={userDetail} />
      
    </div>
  );
};



export default UserDetails;
