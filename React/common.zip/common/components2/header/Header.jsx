import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Container from "@mui/material/Container";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import logo from "../images/naukri_Logo.png";
import { white } from "material-ui/styles/colors";
import { Link } from "react-router-dom";

const pages = ["Jobs", "Companies", "Services"];

function Header() {
  const [anchorElNav, setAnchorElNav] = React.useState(null);

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  return (
    <div className="headesec">
      <AppBar
        className="main"
        position="fixed"
        sx={{
          backgroundColor: white,
          // displayFlex: "row",
          // textAlign: "center",
          height: "90px",
          paddingLeft: "45px",
        }}
      >
        <Container maxWidth="xl">
          <Toolbar>
            <Typography>
              <img src={logo} alt="icon" />
            </Typography>

            <Box sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}>
              <IconButton
                size="large"
                aria-label="account of current user"
                aria-controls="menu-appbar"
                aria-haspopup="true"
                onClick={handleOpenNavMenu}
                color="inherit"
              >
                <MenuIcon />
              </IconButton>
              <Menu
                id="menu-appbar"
                anchorEl={anchorElNav}
                anchorOrigin={{
                  vertical: "bottom",
                  horizontal: "left",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "left",
                }}
                open={Boolean(anchorElNav)}
                onClose={handleCloseNavMenu}
                sx={{
                  display: { xs: "block", md: "none" },
                }}
              >
                {pages.map((page) => (
                  <MenuItem key={page} onClick={handleCloseNavMenu}>
                    <Typography textAlign="center">{page}</Typography>
                  </MenuItem>
                ))}
              </Menu>
            </Box>

            <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
              {pages.map((page) => (
                <Button
                  key={page}
                  onClick={handleCloseNavMenu}
                  sx={{
                    my: 2,
                    color: "black",
                    display: "block",
                  }}
                >
                  {page}
                </Button>
              ))}
            </Box>

            <Box
              m={1}
              //margin
              display="flex"
              justifyContent="space-between"
              alignItems="flex-end"
            >
              <Button
                className="login-btn"
                variant="contained"
                sx={{
                  height: 40,
                  borderRadius: "25px",
                  border: "1px solid blue",
                  color: "blue",
                  // backgroundColor: "white",
                  backgroundColor: "white",
                  "&:hover": {
                    backgroundColor: "var(--N100,#fff)",
                    opacity: [0.9, 0.8, 0.7],
                  },
                }}
              >
                Login
              </Button>
            </Box>
            <Box
              m={1}
              //margin
              display="flex"
              justifyContent="flex-end"
              alignItems="flex-end"
            >
              <Button
                variant="contained"
                color="warning"
                sx={{
                  height: 40,
                  borderRadius: "25px",
                  backgroundColor: "var(--S100,#f05537)",
                }}
              >
                Register
              </Button>
            </Box>

            <Box sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}>
              <Button
                onClick={handleCloseNavMenu}
                sx={{
                  my: 2,
                  color: "black",
                  display: "block",
                }}
              >
                For employees
              </Button>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
    </div>
  );
}
export default Header;
