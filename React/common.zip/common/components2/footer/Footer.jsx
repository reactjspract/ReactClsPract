import React from "react";

const Footer = () => {
  return (
    <div className="footer-sec">
      <h3>footer page.....</h3>
    </div>
  );
};

export default Footer;
