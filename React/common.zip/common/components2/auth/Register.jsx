import React, { useState, Navigate } from "react";

const Register = ({ auth, setAuth }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");

  const handleUsernameChange = (e) => {
    setUsername(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handleSignup = (e) => {
    e.preventDefault();

    // Save the values in local storage
    localStorage.setItem("username", username);
    localStorage.setItem("password", password);
    localStorage.setItem("email", email);

    // Redirect to the login page
    // window.location.href = "/main";
  };

  return (
    <div>
      <h1>Signup</h1>
      <form onSubmit={handleSignup}>
        <input
          type="text"
          value={username}
          onChange={handleUsernameChange}
          placeholder="Username"
        />
        <input
          type="email"
          value={email}
          onChange={handleEmailChange}
          placeholder="email"
        />
        <input
          type="password"
          value={password}
          onChange={handlePasswordChange}
          placeholder="Password"
        />
        <button type="submit">Register</button>
        {auth ? <Navigate to="/" /> : <h2>auth false</h2>}
      </form>
    </div>
  );
};

export default Register;
