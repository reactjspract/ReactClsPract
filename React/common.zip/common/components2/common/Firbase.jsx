import * as firebase from "firebase";
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCE3Q3iOolTFdLQ-QNhOCIlj2G_qn4M3HE",
  authDomain: "ecommerce-5298d.firebaseapp.com",
  projectId: "ecommerce-5298d",
  storageBucket: "ecommerce-5298d.appspot.com",
  messagingSenderId: "904439029695",
  appId: "1:904439029695:web:dd251ecb6e4da17ef30b0a",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export const auth = firebase.auth();
export const googleAuthProvider = new firebase.auth.GoogleAuthProvider();
