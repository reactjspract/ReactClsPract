import React from 'react'

const MainPage = () => {
  return (
      <div>
          <h3>Main  page</h3>
    </div>
  )
}

export default MainPage