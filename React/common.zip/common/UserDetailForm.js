import React, { useState, useRef } from "react";

const UserDetailForm = () => {
  const [userDetails, setuserDetails] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    dob: "",
    gender: "",
    lang: [],
  });
  const [userDetailsError, setuserDetailsError] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    dob: "",
    gender: "",
    lang: "",
  });

  const firstNameRef = useRef();
  const lastNameRef = useRef();
  const emailRef = useRef();
  const passwordRef = useRef();
  const dobRef = useRef();

  const { firstName, lastName, email, password, dob, lang } = userDetails;

  const handleChange = (e) => {
    const { name, type, value } = e.target;
    if (name === "firstName") {
      if (!value) {
        setuserDetailsError({
          ...userDetailsError,
          firstName: "Please enter the firstName",
        });
      } else if (value.length < 4) {
        setuserDetailsError({
          ...userDetailsError,
          firstName: "Please first name must be 4 character lenght",
        });
      } else if (value.length >= 30) {
        setuserDetailsError({
          ...userDetailsError,
          firstName: "Please first name not exceeded more than 30 characters",
        });
      } else {
        setuserDetailsError({
          ...userDetailsError,
          firstName: "",
        });
      }
    } else if (name === "lastName") {
      if (!value) {
        setuserDetailsError({
          ...userDetailsError,
          lastName: "Please enter the lastName",
        });
      } else if (value.length < 4) {
        setuserDetailsError({
          ...userDetailsError,
          lastName: "Please last name must be 4 character lenght",
        });
      } else if (value.length >= 30) {
        setuserDetailsError({
          ...userDetailsError,
          lastName: "Please last name not exceeded more than 30 characters",
        });
      } else {
        setuserDetailsError({
          ...userDetailsError,
          lastName: "",
        });
      }
    } else if (name === "email") {
      const regex =
        // eslint-disable-next-line no-useless-escape
        /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
      if (!value) {
        setuserDetailsError({
          ...userDetailsError,
          email: "Please enter the email",
        });
      } else if (value.length < 7) {
        setuserDetailsError({
          ...userDetailsError,
          email: "Please email must be 7 character lenght",
        });
      } else if (value.length >= 30) {
        setuserDetailsError({
          ...userDetailsError,
          email: "Please email not exceeded more than 30 characters",
        });
      } else if (!regex.test(value)) {
        setuserDetailsError({
          ...userDetailsError,
          email: "Please email not meet the pattern",
        });
      } else {
        setuserDetailsError({
          ...userDetailsError,
          email: "",
        });
      }
    } else if (name === "password") {
      const regex =
        /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/;

      if (!value) {
        setuserDetailsError({
          ...userDetailsError,
          password: "Please enter the password",
        });
      } else if (value.length < 8) {
        setuserDetailsError({
          ...userDetailsError,
          password: "Please password must be 8 character lenght",
        });
      } else if (value.length >= 30) {
        setuserDetailsError({
          ...userDetailsError,
          password: "Please password not exceeded more than 30 characters",
        });
      } else if (!regex.test(value)) {
        setuserDetailsError({
          ...userDetailsError,
          password: "Please password not meet the pattern",
        });
      } else {
        setuserDetailsError({
          ...userDetailsError,
          password: "",
        });
      }
    }

    if (type === "checkbox") {
      let langs = [...lang];
      if (langs.includes(value)) {
        langs = langs.filter((item) => item !== value);
      } else {
        langs.push(value);
      }
      setuserDetails({
        ...userDetails,
        lang: langs,
      });
    } else {
      setuserDetails({
        ...userDetails,
        [name]: value,
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!firstName || userDetailsError.firstName) {
      firstNameRef.current.focus();
      if (!firstName) {
        setuserDetailsError({
          ...userDetailsError,
          firstName: "Please give first Name",
        });
      }
    } else if (!lastName || userDetailsError.lastName) {
      lastNameRef.current.focus();
      if (!lastName) {
        setuserDetailsError({
          ...userDetailsError,
          lastName: "Please give last Name",
        });
      }
    } else if (!email || userDetailsError.email) {
      emailRef.current.focus();
      if (!email) {
        setuserDetailsError({
          ...userDetailsError,
          email: "Please give email",
        });
      }
    } else if (!password || userDetailsError.password) {
      passwordRef.current.focus();
      if (!password) {
        setuserDetailsError({
          ...userDetailsError,
          password: "Please give password",
        });
      }
    } else if (!dob || userDetailsError.dob) {
      dobRef.current.focus();
      if (!dob) {
        setuserDetailsError({
          ...userDetailsError,
          dob: "Please give DOB",
        });
      }
    } else {
      console.log("Submitted", userDetails);
    }
  };

  return (
    <div className="user-detail-form">
      <h2>User Detail Form</h2>
      <form>
        <fieldset>
          <legend>Personalia:</legend>
          <div className="form-item">
            <label htmlFor="firstName">First Name:</label>
            <input
              type="text"
              placeholder="Enter First name"
              id="firstName"
              value={firstName}
              name={"firstName"}
              onChange={handleChange}
              ref={firstNameRef}
            />
          </div>
          {userDetailsError.firstName && (
            <p style={{ color: "red" }}>*{userDetailsError.firstName}</p>
          )}
          <div className="form-item">
            <label htmlFor="lastName">Last Name:</label>
            <input
              type="text"
              placeholder="Enter Last name"
              id="lastName"
              value={lastName}
              name={"lastName"}
              onChange={handleChange}
              ref={lastNameRef}
            />
          </div>
          {userDetailsError.lastName && (
            <p style={{ color: "red" }}>*{userDetailsError.lastName}</p>
          )}
          <div className="form-item">
            <label htmlFor="email">Email:</label>
            <input
              type="email"
              placeholder="Enter Email"
              id="email"
              name="email"
              value={email}
              onChange={handleChange}
              ref={emailRef}
            />
          </div>
          {userDetailsError.email && (
            <p style={{ color: "red" }}>*{userDetailsError.email}</p>
          )}
          <div className="form-item">
            <label htmlFor="password">Password:</label>
            <input
              type="password"
              placeholder="Enter Password"
              id="password"
              name="password"
              value={password}
              onChange={handleChange}
              ref={passwordRef}
            />
          </div>
          {userDetailsError.password && (
            <p style={{ color: "red" }}>*{userDetailsError.password}</p>
          )}
          <div className="form-item">
            <label htmlFor="dob">Date of Birth:</label>
            <input
              type="date"
              placeholder="Enter Date of Birth"
              id="dob"
              name="dob"
              value={dob}
              onChange={handleChange}
              ref={dobRef}
            />
          </div>
          {userDetailsError.dob && (
            <p style={{ color: "red" }}>*{userDetailsError.dob}</p>
          )}
          <div className="form-item">
            <label htmlFor="male">Gender:</label>
            <div>
              <label htmlFor="male">Male</label>
              <input
                type="radio"
                value="male"
                id="male"
                name="gender"
                onChange={handleChange}
              />
            </div>
            <div>
              <label htmlFor="female">Female</label>
              <input
                type="radio"
                value="female"
                id="female"
                name="gender"
                onChange={handleChange}
              />
            </div>
            <div>
              <label htmlFor="transgender">Transgender</label>
              <input
                type="radio"
                value="transgender"
                id="transgender"
                name="gender"
                onChange={handleChange}
              />
            </div>
          </div>
          <div className="form-item">
            <label htmlFor="telugu">Languages Known:</label>
            <div>
              <label htmlFor="telugu">Telugu</label>
              <input
                type="checkbox"
                value="telugu"
                id="telugu"
                name="lang"
                onChange={handleChange}
              />
            </div>
            <div>
              <label htmlFor="hindi">Hindi</label>
              <input
                type="checkbox"
                value="hindi"
                id="hindi"
                name="lang"
                onChange={handleChange}
              />
            </div>
            <div>
              <label htmlFor="english">English</label>
              <input
                type="checkbox"
                value="english"
                id="english"
                name="lang"
                onChange={handleChange}
              />
            </div>
          </div>
          <br />
          <div className="form-item btn-group">
            <button onClick={handleSubmit}>Submit</button>
            <button className="danger">Cancel</button>
          </div>
        </fieldset>
      </form>
    </div>
  );
};

export default UserDetailForm;
