// This constant is used to identify the action type when dispatching actions to the reducer.
import { combineReducers } from 'redux';
import { GET_FULL_NAME } from './types';  

const initialNameState = {
  firstName: "kalyani",
  lastName: "Rayavarapu",
  fullName: ""
}

const initialCountState = {
  count:0
}
/*
The rootReducer function is the main reducer for managing the state of the name - related data.
It takes two arguments: state(representing the current state) and action(representing the dispatched action).

Case GET_FULL_NAME: If the dispatched action has a type of GET_FULL_NAME, 
  the reducer updates the fullName property in the state by concatenating the firstName and lastName properties. the reducer returns a new state object.
*/

export const nameReducer = (state=initialNameState,action) => {
  switch (action.type) {
    case GET_FULL_NAME:
      return { ...state,fullName: state.firstName + state.lastName } // 
    case 'GET_NAME':
      return { ...state,firstName: state.firstName +" Chowdary" }  
    default:
      return state
  }
}

export const countReducer = (state = initialCountState, action) => {
  if (action.type === 'COUNT_INC') {
    return{...state, count: state.count+1}
  } else if (action.type === 'COUNT_DEC') {
    return{...state, count: state.count-1}
  } else {
    return state
  }
}

export const rootReducer = combineReducers({nameReducer, countReducer})