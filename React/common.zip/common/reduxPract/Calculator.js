import React from "react";
import { useDispatch, useSelector } from "react-redux";

const Calculator = () => {
  const dispatch = useDispatch();
  // const userName = useSelector((state) => state.nameReducer.fullName);
  // const countVal = useSelector(state => state.countReducer.count);

  const { fullName, firstName, lastName } = useSelector(state=>state.nameReducer);
  const { count } = useSelector(state => state.countReducer);
  
  return (
    <div>
      <h3>Calculated by {fullName}</h3>
      <p>Firstname is {firstName} and last name is {lastName}</p>
      <h4>Destructuring from store, full name is {fullName} </h4>
      <p>Count is {count} </p>
      <button onClick={()=>dispatch({type:"COUNT_INC"})}>Count Inc</button><br/>
      <button onClick={()=>dispatch({type:"COUNT_DEC"})}>Count Dec</button>
    </div>
  );
};

export default Calculator;
