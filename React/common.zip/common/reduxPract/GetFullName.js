import { useSelector,useDispatch } from "react-redux";
import { GET_FULL_NAME } from './types';

const GetFullName = () => {
  const dispatch = useDispatch();
  const userFullName = useSelector(state => state.nameReducer.fullName);
  console.log(userFullName);

  return (
    <>
      <h3>Get fullname using redux concept</h3>
      <p>User fullname is {userFullName}</p>
      <button onClick={()=>dispatch({ type: GET_FULL_NAME })}>Get FullName</button>
    </>
  )
}

export default GetFullName;

// or old and using in class component
// components/GetFullName.js
// import React from 'react';
// import { connect } from 'react-redux';

// const GetFullName = ({ fullName }) => {
//   return <div>Full Name: {fullName}</div>;
// };

// export {GetFullName};

// // components/GetFullName.js (continued)
// const mapStateToProps = (state) => {
//   return {
//     fullName: state.fullName,
//   };
// };

// export default connect(mapStateToProps)(GetFullName);

