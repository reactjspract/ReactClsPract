import React, { useState } from "react";
import todoItems from "./todo.json";

const TodoApp = () => {
  const [newTodo, setNewTodo] = useState("");
  const [todoTasks, setTodoTasks] = useState(todoItems);

  const [isPopupOpen, setIsPopupOpen] = useState(false);
  const [inputValue, setInputValue] = useState("");
  const [selectedTodo, setSelectedTodo] = useState("");
  const [taskId, setTaskId] = useState(todoItems.length + 1);

  const handleEditClick = (todo) => {
    setSelectedTodo(todo);
    setInputValue(todo.title);
    setIsPopupOpen(true);
  };

  const handleInputChange = (event) => {
    setInputValue(event.target.value);
  };

  const handleSaveClick = () => {
    if (selectedTodo) {
      const updatedItems = todoTasks.map((todo) => {
        if (todo.id === selectedTodo.id) {
          return {
            ...todo,
            title: inputValue,
          };
        }
        return todo;
      });

      setTodoTasks(updatedItems);
    }

    setIsPopupOpen(false);
    setSelectedTodo(null);
    setInputValue("");
  };

  const handleUpdate = (todoItem) => {
    const updatedItems = todoTasks.map((todo) => {
      if (todo.id === todoItem.id) {
        return {
          ...todo,
          completed: !todo.completed,
        };
      }
      return todo;
    });

    setTodoTasks(updatedItems);
  };

  const handleSubmit = () => {
    if (newTodo && !todoTasks.some((task) => task.title === newTodo)) {
      const newTask = {
        id: taskId,
        title: newTodo,
        completed: false,
      };
      setTodoTasks([...todoTasks, newTask]);
      setNewTodo("");
      setTaskId(taskId + 1);
    }
  };

  // const handleDelete = (todoTask) => {
  //   const deletedItems = todoTasks.filter((todo) => todo.id !== todoTask.id);
  //   setTodoTasks(deletedItems);
  // };
  const handleDelete = (todoTask) => {
    const deletedItems = todoTasks
      .filter((todo) => todo.id !== todoTask.id)
      .map((todo, index) => ({ ...todo, id: index + 1 }));
    setTodoTasks(deletedItems);
  };

  return (
    <div>
      <h3>Todo app page</h3>
      <div className="main-container">
        <input
          type="text"
          name="text"
          id="text"
          placeholder="Add todo here"
          value={newTodo}
          onChange={(e) => setNewTodo(e.target.value)}
        />
        &nbsp;
        <button onClick={handleSubmit}>Add</button>
      </div>
      <br />
      <div className="todo-list">
        <ul className="todo-ul">
          {todoTasks.map((todo) => {
            return (
              <li key={todo.id}>
                {todo.id} &nbsp;
                <span>{todo.title}</span> &nbsp;
                <input
                  type="checkbox"
                  name="check"
                  id="check"
                  checked={todo.completed}
                  onChange={() => handleUpdate(todo)}
                />{" "}
                &nbsp;
                <button
                  style={{
                    padding: "3px",
                    backgroundColor: "orange",
                    fontSize: "12px",
                  }}
                  onClick={() => handleEditClick(todo)}
                >
                  Edit
                </button>{" "}
                &nbsp; &nbsp;{" "}
                <button
                  style={{
                    padding: "3px",
                    fontSize: "12px",
                  }}
                  onClick={() => handleDelete(todo)}
                >
                  Delete
                </button>
              </li>
            );
          })}
        </ul>
      </div>
      <br />
      {isPopupOpen && (
        <div className="popup">
          <input type="text" value={inputValue} onChange={handleInputChange} />
          <button onClick={handleSaveClick}>Save</button>
          <button onClick={() => setIsPopupOpen(false)}>Close</button>
        </div>
      )}
    </div>
  );
};

export default TodoApp;
